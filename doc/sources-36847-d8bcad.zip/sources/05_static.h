#pragma once

struct Counter {
public:
    Counter();
    ~Counter();
    static int count;
};